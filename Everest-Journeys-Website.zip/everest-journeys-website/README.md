# Everest Journeys Website

6-page static website:
- Home
- About
- Services
- Industries
- Sales Funnel & Automation
- Resources
- Contact / Free Audit

Upload all files to the existing GitHub repository and deploy through Netlify or another static host.

Before production:
- Replace the text logo with the official logo asset.
- Connect the contact form to a real form endpoint/CRM.
- Add final OG image and favicon.
- Verify the domain in Google Search Console and submit sitemap.xml.
- Add only factual Organization/Service structured data after the final business details are confirmed.
